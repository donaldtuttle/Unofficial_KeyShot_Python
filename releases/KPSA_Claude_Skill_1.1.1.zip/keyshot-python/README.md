Bundled complete Unofficial_KeyShot_Python AI/scripts/API snapshot. Connected GitHub and KeyShot MCP tools are optional, not included.
LICENSE: GPLv3. README and LICENSE agree.
Install to Claude Customize > Skills (ZIP upload), or .claude/skills or ~/.claude/skills for Claude Code.
